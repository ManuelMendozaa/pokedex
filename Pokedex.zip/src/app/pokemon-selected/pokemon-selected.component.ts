import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pokemon-selected',
  templateUrl: './pokemon-selected.component.html',
  styleUrls: ['./pokemon-selected.component.css']
})
export class PokemonSelectedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
